<html>
<style>
th {
  width: 120px;
  height: 25px;
  background-color: lightgrey;
}
</style>

<body>

<h2>The below data has been sent to the server for processing:</h2>
<table>
  <tr>
    <th>Variable Name</th>
	<th>Variable Value</th>
  <tr>
    <td style="font-weight:bold;">var1</td>
	<td><?php echo $_GET["var1"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var2</td>
	<td><?php echo $_GET["var2"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var3</td>
	<td><?php echo $_GET["var3"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var4</td>
	<td><?php echo $_GET["var4"]; ?></td>
  </tr>
  <tr>
    <td><br></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var5</td>
	<td><?php echo $_GET["var5"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var6</td>
	<td><?php echo $_GET["var6"]; ?></td>
  </tr>
  <tr>
    <td><br></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var7</td>
	<td><?php echo $_GET["var7"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var8</td>
	<td><?php echo $_GET["var8"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var9</td>
	<td><?php echo $_GET["var9"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var10</td>
	<td><?php echo $_GET["var10"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var11</td>
	<td><?php echo $_GET["var11"]; ?></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var12</td>
	<td><?php echo $_GET["var12"]; ?></td>
  </tr>
  <tr>
    <td><br></td>
  </tr>
  <tr>
    <td style="font-weight:bold;">var13</td>
	<td><?php echo $_GET["var13"]; ?></td>
  </tr>
  
</table>

</body>
</html>